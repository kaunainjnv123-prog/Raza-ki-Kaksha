export const colors = {
  primary: '#1F7A63',
  accent: '#FF7A00',
  background: '#F5F5F5',
  card: '#FFFFFF',
  text: '#1F2933',
  muted: '#6B7280',
  success: '#16A34A',
  warning: '#F59E0B',
  danger: '#EF4444',
  border: '#E5E7EB',
};

export const spacing = {
  xs: 6,
  sm: 10,
  md: 16,
  lg: 24,
  xl: 32,
};

export const radius = {
  sm: 10,
  md: 16,
  lg: 22,
};

export const shadow = {
  ios: {
    shadowColor: '#000',
    shadowOpacity: 0.08,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 6 },
  },
  android: {
    elevation: 4,
  },
};
