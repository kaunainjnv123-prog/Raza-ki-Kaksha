import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {
  announcements as initialAnnouncements,
  notifications as initialNotifications,
  doubts as initialDoubts,
  lectures,
  materials,
  tests,
  adminUploads as initialUploads,
} from './data';

export type Role = 'student' | 'admin';

export type Result = {
  id: string;
  testId: string;
  score: number;
  total: number;
  date: string;
  breakdown: number[];
};

type AppContextState = {
  role: Role;
  name: string;
  bookmarks: string[];
  downloads: string[];
  completedLectures: string[];
  announcements: typeof initialAnnouncements;
  notifications: typeof initialNotifications;
  doubts: typeof initialDoubts;
  results: Result[];
  uploads: typeof initialUploads;
  setRole: (role: Role) => void;
  setName: (name: string) => void;
  toggleBookmark: (id: string) => void;
  toggleDownload: (id: string) => void;
  markLectureComplete: (id: string) => void;
  addDoubt: (question: string) => void;
  addReply: (doubtId: string, message: string, author: string) => void;
  submitTest: (testId: string, answers: number[]) => Result;
  addNotification: (title: string, body: string, type: string) => void;
  addAnnouncement: (title: string, body: string) => void;
  addUpload: (type: string, title: string) => void;
};

const AppContext = createContext<AppContextState | null>(null);

const STORAGE_KEYS = {
  role: 'rk_role',
  name: 'rk_name',
  bookmarks: 'rk_bookmarks',
  downloads: 'rk_downloads',
  completed: 'rk_completed',
  results: 'rk_results',
};

export const AppProvider = ({ children }: { children: React.ReactNode }) => {
  const [role, setRole] = useState<Role>('student');
  const [name, setName] = useState('Raza Learner');
  const [bookmarks, setBookmarks] = useState<string[]>([]);
  const [downloads, setDownloads] = useState<string[]>([]);
  const [completedLectures, setCompletedLectures] = useState<string[]>([]);
  const [announcements, setAnnouncements] = useState(initialAnnouncements);
  const [notifications, setNotifications] = useState(initialNotifications);
  const [doubts, setDoubts] = useState(initialDoubts);
  const [results, setResults] = useState<Result[]>([]);
  const [uploads, setUploads] = useState(initialUploads);

  useEffect(() => {
    const hydrate = async () => {
      const storedRole = await AsyncStorage.getItem(STORAGE_KEYS.role);
      const storedName = await AsyncStorage.getItem(STORAGE_KEYS.name);
      const storedBookmarks = await AsyncStorage.getItem(STORAGE_KEYS.bookmarks);
      const storedDownloads = await AsyncStorage.getItem(STORAGE_KEYS.downloads);
      const storedCompleted = await AsyncStorage.getItem(STORAGE_KEYS.completed);
      const storedResults = await AsyncStorage.getItem(STORAGE_KEYS.results);
      if (storedRole) setRole(storedRole as Role);
      if (storedName) setName(storedName);
      if (storedBookmarks) setBookmarks(JSON.parse(storedBookmarks));
      if (storedDownloads) setDownloads(JSON.parse(storedDownloads));
      if (storedCompleted) setCompletedLectures(JSON.parse(storedCompleted));
      if (storedResults) setResults(JSON.parse(storedResults));
    };
    hydrate();
  }, []);

  useEffect(() => {
    AsyncStorage.setItem(STORAGE_KEYS.role, role);
  }, [role]);

  useEffect(() => {
    AsyncStorage.setItem(STORAGE_KEYS.name, name);
  }, [name]);

  useEffect(() => {
    AsyncStorage.setItem(STORAGE_KEYS.bookmarks, JSON.stringify(bookmarks));
  }, [bookmarks]);

  useEffect(() => {
    AsyncStorage.setItem(STORAGE_KEYS.downloads, JSON.stringify(downloads));
  }, [downloads]);

  useEffect(() => {
    AsyncStorage.setItem(STORAGE_KEYS.completed, JSON.stringify(completedLectures));
  }, [completedLectures]);

  useEffect(() => {
    AsyncStorage.setItem(STORAGE_KEYS.results, JSON.stringify(results));
  }, [results]);

  const toggleBookmark = (id: string) => {
    setBookmarks((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const toggleDownload = (id: string) => {
    setDownloads((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const markLectureComplete = (id: string) => {
    setCompletedLectures((prev) => (prev.includes(id) ? prev : [...prev, id]));
  };

  const addDoubt = (question: string) => {
    setDoubts((prev) => [
      {
        id: `doubt-${Date.now()}`,
        question,
        student: name,
        status: 'Open',
        replies: [],
      },
      ...prev,
    ]);
  };

  const addReply = (doubtId: string, message: string, author: string) => {
    setDoubts((prev) =>
      prev.map((doubt) =>
        doubt.id === doubtId
          ? {
              ...doubt,
              status: 'Answered',
              replies: [
                ...doubt.replies,
                {
                  id: `rep-${Date.now()}`,
                  author,
                  message,
                  time: 'Just now',
                },
              ],
            }
          : doubt
      )
    );
  };

  const submitTest = (testId: string, answers: number[]) => {
    const test = tests.find((item) => item.id === testId);
    const total = test?.questions.length ?? 0;
    let score = 0;
    test?.questions.forEach((question, index) => {
      if (question.answer === answers[index]) score += 1;
    });
    const result: Result = {
      id: `res-${Date.now()}`,
      testId,
      score,
      total,
      date: new Date().toLocaleDateString(),
      breakdown: answers,
    };
    setResults((prev) => [result, ...prev]);
    return result;
  };

  const addNotification = (title: string, body: string, type: string) => {
    setNotifications((prev) => [
      {
        id: `not-${Date.now()}`,
        title,
        body,
        type,
        date: 'Just now',
        read: false,
      },
      ...prev,
    ]);
  };

  const addAnnouncement = (title: string, body: string) => {
    setAnnouncements((prev) => [
      { id: `ann-${Date.now()}`, title, body, date: 'Just now' },
      ...prev,
    ]);
  };

  const addUpload = (type: string, title: string) => {
    setUploads((prev) => [
      { id: `up-${Date.now()}`, type, title, date: 'Just now' },
      ...prev,
    ]);
  };

  const value = useMemo(
    () => ({
      role,
      name,
      bookmarks,
      downloads,
      completedLectures,
      announcements,
      notifications,
      doubts,
      results,
      uploads,
      setRole,
      setName,
      toggleBookmark,
      toggleDownload,
      markLectureComplete,
      addDoubt,
      addReply,
      submitTest,
      addNotification,
      addAnnouncement,
      addUpload,
    }),
    [
      role,
      name,
      bookmarks,
      downloads,
      completedLectures,
      announcements,
      notifications,
      doubts,
      results,
      uploads,
    ]
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within AppProvider');
  }
  return context;
};

export { lectures, materials, tests };
