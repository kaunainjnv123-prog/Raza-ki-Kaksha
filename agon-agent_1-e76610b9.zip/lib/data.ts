export const chapters = [
  'Haloalkanes and Haloarenes',
  'Alcohols, Phenols and Ethers',
  'Aldehydes, Ketones and Carboxylic Acids',
  'Amines',
  'Biomolecules',
  'Polymers',
  'Chemistry in Everyday Life',
];

export const lectures = [
  {
    id: 'lec-1',
    title: 'Intro to Haloalkanes: Structure & Nomenclature',
    chapter: chapters[0],
    duration: '32 min',
    date: 'Today 4:30 PM',
    type: 'Recorded Lecture',
  },
  {
    id: 'lec-2',
    title: 'SN1 vs SN2 Mechanisms Deep Dive',
    chapter: chapters[0],
    duration: '41 min',
    date: 'Tomorrow 5:00 PM',
    type: 'Live Class',
  },
  {
    id: 'lec-3',
    title: 'Alcohols: Preparation Methods',
    chapter: chapters[1],
    duration: '28 min',
    date: 'Yesterday 6:00 PM',
    type: 'Recorded Lecture',
  },
  {
    id: 'lec-4',
    title: 'Aldehydes & Ketones: Carbonyl Reactions',
    chapter: chapters[2],
    duration: '36 min',
    date: 'Fri 7:00 PM',
    type: 'Recorded Lecture',
  },
];

export const materials = [
  {
    id: 'mat-1',
    title: 'Haloalkanes Notes - Chapter Summary',
    chapter: chapters[0],
    type: 'PDF Notes',
    size: '3.4 MB',
  },
  {
    id: 'mat-2',
    title: 'Alcohols Reaction Mechanisms Chart',
    chapter: chapters[1],
    type: 'Reaction Chart',
    size: '1.2 MB',
  },
  {
    id: 'mat-3',
    title: 'Amines Quick Revision Sheet',
    chapter: chapters[3],
    type: 'Revision Sheet',
    size: '900 KB',
  },
  {
    id: 'mat-4',
    title: 'Biomolecules Mind Map',
    chapter: chapters[4],
    type: 'Mind Map',
    size: '2.1 MB',
  },
];

export const tests = [
  {
    id: 'test-1',
    title: 'Haloalkanes Chapter Test',
    chapter: chapters[0],
    questions: [
      {
        id: 'q1',
        question: 'Which solvent favors SN1 reactions?',
        options: ['Polar protic', 'Polar aprotic', 'Non-polar', 'Gas phase'],
        answer: 0,
        explanation: 'SN1 reactions are stabilized by polar protic solvents that stabilize carbocations.',
      },
      {
        id: 'q2',
        question: 'The leaving group ability order is best described as:',
        options: ['F- > Cl- > Br- > I-', 'I- > Br- > Cl- > F-', 'Cl- > Br- > I- > F-', 'Br- > Cl- > I- > F-'],
        answer: 1,
        explanation: 'Iodide is the best leaving group due to weak C-I bond and high polarizability.',
      },
      {
        id: 'q3',
        question: 'SN2 reactions proceed with which stereochemistry?',
        options: ['Retention', 'Inversion', 'Racemization', 'No change'],
        answer: 1,
        explanation: 'SN2 reactions show inversion of configuration due to backside attack.',
      },
    ],
  },
  {
    id: 'test-2',
    title: 'Alcohols Practice Quiz',
    chapter: chapters[1],
    questions: [
      {
        id: 'q1',
        question: 'Lucas test distinguishes between which type of alcohols?',
        options: ['Primary, secondary, tertiary', 'Primary only', 'Secondary only', 'Aromatic only'],
        answer: 0,
        explanation: 'Lucas test distinguishes primary, secondary, and tertiary alcohols based on turbidity.',
      },
      {
        id: 'q2',
        question: 'Oxidation of secondary alcohol gives:',
        options: ['Aldehyde', 'Ketone', 'Carboxylic acid', 'Ether'],
        answer: 1,
        explanation: 'Secondary alcohols oxidize to ketones.',
      },
    ],
  },
];

export const announcements = [
  {
    id: 'ann-1',
    title: 'Classroom Quiz Tonight',
    body: 'Join the live quiz at 8:00 PM on Haloalkanes. Instant results and badge for top scorers!',
    date: 'Today',
  },
  {
    id: 'ann-2',
    title: 'New Reaction Mechanism Chart',
    body: 'Uploaded a detailed chart for alcohol dehydration mechanisms. Check study materials.',
    date: 'Yesterday',
  },
];

export const notifications = [
  {
    id: 'not-1',
    title: 'Live Class Reminder',
    body: 'SN1 vs SN2 live session starts in 2 hours.',
    type: 'Class Reminder',
    date: 'Today',
    read: false,
  },
  {
    id: 'not-2',
    title: 'Test Alert',
    body: 'Haloalkanes Chapter Test available now.',
    type: 'Test Alert',
    date: 'Yesterday',
    read: true,
  },
];

export const doubts = [
  {
    id: 'doubt-1',
    question: 'Why does tertiary alcohol show immediate turbidity in Lucas test?',
    student: 'Ananya Singh',
    status: 'Answered',
    replies: [
      {
        id: 'rep-1',
        author: 'Raza Sir',
        message: 'Tertiary alcohol forms stable carbocation quickly, leading to immediate substitution.',
        time: '2h ago',
      },
    ],
  },
  {
    id: 'doubt-2',
    question: 'How to predict major product in dehydration reactions?',
    student: 'Rohit Mehta',
    status: 'Open',
    replies: [],
  },
];

export const upcomingClasses = [
  {
    id: 'cls-1',
    topic: 'Aldehydes & Ketones: Important Conversions',
    time: 'Sat 6:00 PM',
  },
  {
    id: 'cls-2',
    topic: 'Amines Practice Session',
    time: 'Sun 5:30 PM',
  },
];

export const performanceStats = [
  { label: 'Lectures Completed', value: 18, total: 28 },
  { label: 'Tests Attempted', value: 6, total: 10 },
  { label: 'Average Score', value: 78, total: 100 },
];

export const adminUploads = [
  { id: 'up-1', type: 'Lecture Video', title: 'Carbonyl Reactions Part 1', date: 'Today' },
  { id: 'up-2', type: 'PDF Notes', title: 'Amines Quick Notes', date: 'Yesterday' },
  { id: 'up-3', type: 'Assignment', title: 'Haloalkanes Practice Sheet', date: 'Mon' },
];
