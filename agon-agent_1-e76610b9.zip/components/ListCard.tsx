import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { colors, radius, spacing, shadow } from '../lib/theme';
import Pill from './Pill';
import Ionicons from '@expo/vector-icons/Ionicons';

type Props = {
  title: string;
  subtitle: string;
  meta?: string;
  pill?: string;
  icon?: keyof typeof Ionicons.glyphMap;
  onPress?: () => void;
  rightSlot?: React.ReactNode;
};

const ListCard = ({ title, subtitle, meta, pill, icon = 'play-circle', onPress, rightSlot }: Props) => {
  return (
    <Pressable onPress={onPress} style={styles.card}>
      <View style={styles.iconWrap}>
        <Ionicons name={icon} size={22} color={colors.primary} />
      </View>
      <View style={styles.content}>
        <Text style={styles.title}>{title}</Text>
        <Text style={styles.subtitle}>{subtitle}</Text>
        <View style={styles.metaRow}>
          {pill ? <Pill label={pill} tone="accent" /> : null}
          {meta ? <Text style={styles.meta}>{meta}</Text> : null}
        </View>
      </View>
      {rightSlot}
    </Pressable>
  );
};

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: spacing.md,
    backgroundColor: colors.card,
    borderRadius: radius.md,
    marginBottom: spacing.sm,
    ...shadow.ios,
    ...shadow.android,
  },
  iconWrap: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#E6F4F0',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: spacing.md,
  },
  content: {
    flex: 1,
  },
  title: {
    fontFamily: 'Poppins_600SemiBold',
    color: colors.text,
  },
  subtitle: {
    color: colors.muted,
    marginTop: 2,
    fontFamily: 'Poppins_400Regular',
  },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginTop: spacing.xs,
  },
  meta: {
    color: colors.muted,
    fontSize: 12,
    fontFamily: 'Poppins_400Regular',
  },
});

export default ListCard;
