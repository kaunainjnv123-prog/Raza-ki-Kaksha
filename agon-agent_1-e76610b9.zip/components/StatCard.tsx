import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { colors, radius, spacing, shadow } from '../lib/theme';

type Props = {
  title: string;
  value: string;
  subtitle?: string;
};

const StatCard = ({ title, value, subtitle }: Props) => {
  return (
    <View style={styles.card}>
      <Text style={styles.value}>{value}</Text>
      <Text style={styles.title}>{title}</Text>
      {subtitle ? <Text style={styles.subtitle}>{subtitle}</Text> : null}
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    flex: 1,
    backgroundColor: colors.card,
    borderRadius: radius.md,
    padding: spacing.md,
    ...shadow.ios,
    ...shadow.android,
  },
  value: {
    fontSize: 22,
    color: colors.primary,
    fontFamily: 'Montserrat_700Bold',
  },
  title: {
    marginTop: spacing.xs,
    color: colors.text,
    fontFamily: 'Poppins_500Medium',
  },
  subtitle: {
    marginTop: 2,
    color: colors.muted,
    fontSize: 12,
    fontFamily: 'Poppins_400Regular',
  },
});

export default StatCard;
