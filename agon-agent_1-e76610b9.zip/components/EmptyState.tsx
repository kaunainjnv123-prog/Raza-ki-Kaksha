import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { colors, spacing } from '../lib/theme';

type Props = {
  icon?: keyof typeof Ionicons.glyphMap;
  title: string;
  subtitle: string;
};

const EmptyState = ({ icon = 'sparkles', title, subtitle }: Props) => {
  return (
    <View style={styles.container}>
      <Ionicons name={icon} size={40} color={colors.accent} />
      <Text style={styles.title}>{title}</Text>
      <Text style={styles.subtitle}>{subtitle}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    padding: spacing.lg,
  },
  title: {
    marginTop: spacing.sm,
    fontFamily: 'Montserrat_700Bold',
    color: colors.text,
  },
  subtitle: {
    marginTop: spacing.xs,
    textAlign: 'center',
    color: colors.muted,
    fontFamily: 'Poppins_400Regular',
  },
});

export default EmptyState;
