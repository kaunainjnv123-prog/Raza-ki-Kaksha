import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { colors, radius, spacing } from '../lib/theme';

type Props = {
  label: string;
  tone?: 'primary' | 'accent' | 'muted';
};

const Pill = ({ label, tone = 'muted' }: Props) => {
  return (
    <View
      style={[
        styles.container,
        tone === 'primary' && styles.primary,
        tone === 'accent' && styles.accent,
      ]}
    >
      <Text
        style={[
          styles.text,
          tone === 'primary' && styles.textPrimary,
          tone === 'accent' && styles.textAccent,
        ]}
      >
        {label}
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: spacing.sm,
    paddingVertical: 4,
    borderRadius: radius.sm,
    backgroundColor: '#EEF5F2',
  },
  primary: {
    backgroundColor: '#E0F2ED',
  },
  accent: {
    backgroundColor: '#FFF1E6',
  },
  text: {
    fontSize: 12,
    color: colors.muted,
    fontFamily: 'Poppins_500Medium',
  },
  textPrimary: {
    color: colors.primary,
  },
  textAccent: {
    color: colors.accent,
  },
});

export default Pill;
