import React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import { colors, spacing } from '../lib/theme';

type Props = {
  title: string;
  subtitle?: string;
};

const SectionHeader = ({ title, subtitle }: Props) => {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>{title}</Text>
      {subtitle ? <Text style={styles.subtitle}>{subtitle}</Text> : null}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginBottom: spacing.sm,
  },
  title: {
    fontSize: 20,
    fontFamily: 'Montserrat_700Bold',
    color: colors.text,
  },
  subtitle: {
    marginTop: 4,
    color: colors.muted,
    fontFamily: 'Poppins_400Regular',
  },
});

export default SectionHeader;
