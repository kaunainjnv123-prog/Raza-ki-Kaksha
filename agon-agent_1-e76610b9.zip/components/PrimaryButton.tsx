import React from 'react';
import { Pressable, StyleSheet, Text, ViewStyle } from 'react-native';
import { colors, radius, spacing } from '../lib/theme';

type Props = {
  title: string;
  onPress: () => void;
  icon?: React.ReactNode;
  variant?: 'primary' | 'outline';
  style?: ViewStyle;
};

const PrimaryButton = ({ title, onPress, icon, variant = 'primary', style }: Props) => {
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.base,
        variant === 'primary' ? styles.primary : styles.outline,
        pressed && { opacity: 0.85 },
        style,
      ]}
    >
      {icon}
      <Text style={[styles.text, variant === 'primary' ? styles.textPrimary : styles.textOutline]}>
        {title}
      </Text>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  base: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.lg,
    borderRadius: radius.md,
  },
  primary: {
    backgroundColor: colors.primary,
  },
  outline: {
    borderWidth: 1,
    borderColor: colors.primary,
    backgroundColor: 'transparent',
  },
  text: {
    fontSize: 15,
    fontFamily: 'Poppins_600SemiBold',
  },
  textPrimary: {
    color: '#fff',
  },
  textOutline: {
    color: colors.primary,
  },
});

export default PrimaryButton;
