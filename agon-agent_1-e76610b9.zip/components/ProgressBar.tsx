import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { colors, radius, spacing } from '../lib/theme';

type Props = {
  label: string;
  value: number;
  total: number;
};

const ProgressBar = ({ label, value, total }: Props) => {
  const percent = Math.min(100, Math.round((value / total) * 100));
  return (
    <View style={styles.container}>
      <View style={styles.row}>
        <Text style={styles.label}>{label}</Text>
        <Text style={styles.value}>{value}/{total}</Text>
      </View>
      <View style={styles.track}>
        <View style={[styles.fill, { width: `${percent}%` }]} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginBottom: spacing.md,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: spacing.xs,
  },
  label: {
    fontFamily: 'Poppins_500Medium',
    color: colors.text,
  },
  value: {
    fontFamily: 'Poppins_500Medium',
    color: colors.primary,
  },
  track: {
    height: 10,
    backgroundColor: '#E6EFEA',
    borderRadius: radius.sm,
  },
  fill: {
    height: 10,
    backgroundColor: colors.primary,
    borderRadius: radius.sm,
  },
});

export default ProgressBar;
