import React, { useState } from 'react';
import { FlatList, StyleSheet, Text, TextInput, View } from 'react-native';
import { colors, radius, spacing } from '../lib/theme';
import { useApp } from '../lib/AppContext';
import PrimaryButton from '../components/PrimaryButton';

const DoubtDetailScreen = ({ route }: { route: any }) => {
  const { doubts, addReply, role, name } = useApp();
  const doubt = doubts.find((item) => item.id === route.params?.id) ?? doubts[0];
  const [reply, setReply] = useState('');

  return (
    <FlatList
      data={doubt.replies}
      keyExtractor={(item) => item.id}
      contentContainerStyle={styles.container}
      ListHeaderComponent={
        <View>
          <Text style={styles.question}>{doubt.question}</Text>
          <Text style={styles.meta}>{doubt.student} • {doubt.status}</Text>
          <Text style={styles.section}>Replies</Text>
        </View>
      }
      renderItem={({ item }) => (
        <View style={styles.replyCard}>
          <Text style={styles.replyAuthor}>{item.author}</Text>
          <Text style={styles.replyMessage}>{item.message}</Text>
          <Text style={styles.replyTime}>{item.time}</Text>
        </View>
      )}
      ListFooterComponent={
        <View style={styles.replyBox}>
          <TextInput
            placeholder={role === 'admin' ? 'Reply as teacher' : 'Add follow-up question'}
            placeholderTextColor={colors.muted}
            value={reply}
            onChangeText={setReply}
            style={styles.input}
          />
          <PrimaryButton
            title="Send Reply"
            onPress={() => {
              if (reply.trim()) {
                addReply(doubt.id, reply.trim(), role === 'admin' ? 'Raza Sir' : name);
                setReply('');
              }
            }}
          />
        </View>
      }
    />
  );
};

const styles = StyleSheet.create({
  container: {
    padding: spacing.lg,
    backgroundColor: colors.background,
  },
  question: {
    fontSize: 20,
    fontFamily: 'Montserrat_700Bold',
    color: colors.text,
  },
  meta: {
    marginTop: spacing.xs,
    color: colors.muted,
    fontFamily: 'Poppins_400Regular',
  },
  section: {
    marginTop: spacing.lg,
    marginBottom: spacing.sm,
    fontFamily: 'Montserrat_700Bold',
    color: colors.text,
  },
  replyCard: {
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    padding: spacing.md,
    marginBottom: spacing.md,
  },
  replyAuthor: {
    fontFamily: 'Poppins_600SemiBold',
    color: colors.text,
  },
  replyMessage: {
    marginTop: spacing.xs,
    fontFamily: 'Poppins_400Regular',
    color: colors.text,
  },
  replyTime: {
    marginTop: spacing.xs,
    fontSize: 12,
    color: colors.muted,
    fontFamily: 'Poppins_400Regular',
  },
  replyBox: {
    marginTop: spacing.md,
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    padding: spacing.md,
  },
  input: {
    backgroundColor: '#F6F9F8',
    borderRadius: radius.md,
    padding: spacing.sm,
    marginBottom: spacing.md,
    fontFamily: 'Poppins_400Regular',
  },
});

export default DoubtDetailScreen;
