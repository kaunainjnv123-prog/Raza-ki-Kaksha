import React, { useState } from 'react';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { colors, radius, spacing } from '../lib/theme';
import { tests } from '../lib/data';
import PrimaryButton from '../components/PrimaryButton';
import { useApp } from '../lib/AppContext';

const TestRunnerScreen = ({ navigation, route }: { navigation: any; route: any }) => {
  const { submitTest } = useApp();
  const test = tests.find((item) => item.id === route.params?.id) ?? tests[0];
  const [answers, setAnswers] = useState<number[]>(Array(test.questions.length).fill(-1));

  const handleSelect = (qIndex: number, optionIndex: number) => {
    setAnswers((prev) => {
      const next = [...prev];
      next[qIndex] = optionIndex;
      return next;
    });
  };

  const handleSubmit = () => {
    const result = submitTest(test.id, answers);
    navigation.replace('Results', { id: result.id });
  };

  return (
    <FlatList
      data={test.questions}
      keyExtractor={(item) => item.id}
      contentContainerStyle={styles.container}
      ListHeaderComponent={
        <View>
          <Text style={styles.title}>{test.title}</Text>
          <Text style={styles.subtitle}>Answer all questions for instant results.</Text>
        </View>
      }
      renderItem={({ item, index }) => (
        <View style={styles.questionCard}>
          <Text style={styles.question}>{index + 1}. {item.question}</Text>
          {item.options.map((option, optionIndex) => {
            const isSelected = answers[index] === optionIndex;
            return (
              <Pressable
                key={option}
                onPress={() => handleSelect(index, optionIndex)}
                style={[styles.option, isSelected && styles.optionSelected]}
              >
                <Text style={[styles.optionText, isSelected && styles.optionTextSelected]}>{option}</Text>
              </Pressable>
            );
          })}
        </View>
      )}
      ListFooterComponent={
        <PrimaryButton title="Submit Test" onPress={handleSubmit} style={{ marginTop: spacing.md }} />
      }
    />
  );
};

const styles = StyleSheet.create({
  container: {
    padding: spacing.lg,
    backgroundColor: colors.background,
  },
  title: {
    fontSize: 22,
    fontFamily: 'Montserrat_700Bold',
    color: colors.text,
  },
  subtitle: {
    marginTop: spacing.xs,
    color: colors.muted,
    fontFamily: 'Poppins_400Regular',
    marginBottom: spacing.md,
  },
  questionCard: {
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    padding: spacing.md,
    marginBottom: spacing.md,
  },
  question: {
    fontFamily: 'Poppins_600SemiBold',
    color: colors.text,
    marginBottom: spacing.sm,
  },
  option: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    padding: spacing.sm,
    marginBottom: spacing.xs,
  },
  optionSelected: {
    borderColor: colors.primary,
    backgroundColor: '#E6F4F0',
  },
  optionText: {
    fontFamily: 'Poppins_400Regular',
    color: colors.text,
  },
  optionTextSelected: {
    color: colors.primary,
    fontFamily: 'Poppins_500Medium',
  },
});

export default TestRunnerScreen;
