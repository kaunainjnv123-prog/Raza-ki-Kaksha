import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { colors, radius, spacing } from '../lib/theme';
import { materials } from '../lib/data';
import PrimaryButton from '../components/PrimaryButton';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useApp } from '../lib/AppContext';

const NotesViewerScreen = ({ route }: { route: any }) => {
  const material = materials.find((item) => item.id === route.params?.id) ?? materials[0];
  const { downloads, toggleDownload } = useApp();
  const isDownloaded = downloads.includes(material.id);

  return (
    <View style={styles.container}>
      <View style={styles.viewer}>
        <Ionicons name="document" size={32} color={colors.card} />
        <Text style={styles.viewerText}>PDF Viewer</Text>
        <Text style={styles.viewerSubtext}>Offline-ready reading mode</Text>
      </View>
      <Text style={styles.title}>{material.title}</Text>
      <Text style={styles.subtitle}>{material.chapter}</Text>
      <View style={styles.metaRow}>
        <Text style={styles.meta}>{material.type}</Text>
        <Text style={styles.meta}>{material.size}</Text>
      </View>
      <Text style={styles.description}>
        This PDF includes mechanism charts, key reactions, and board-focused notes curated for fast revision.
      </Text>
      <PrimaryButton
        title={isDownloaded ? 'Downloaded' : 'Download for Offline'}
        icon={
          <Ionicons
            name={isDownloaded ? 'checkmark-circle' : 'cloud-download'}
            size={18}
            color="#fff"
          />
        }
        onPress={() => toggleDownload(material.id)}
        style={{ marginTop: spacing.lg }}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    padding: spacing.lg,
  },
  viewer: {
    height: 180,
    borderRadius: radius.lg,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  viewerText: {
    marginTop: spacing.sm,
    color: colors.card,
    fontFamily: 'Montserrat_700Bold',
  },
  viewerSubtext: {
    color: '#E7F5EF',
    fontFamily: 'Poppins_400Regular',
  },
  title: {
    marginTop: spacing.lg,
    fontSize: 22,
    fontFamily: 'Montserrat_700Bold',
    color: colors.text,
  },
  subtitle: {
    marginTop: spacing.xs,
    color: colors.muted,
    fontFamily: 'Poppins_400Regular',
  },
  metaRow: {
    flexDirection: 'row',
    gap: spacing.md,
    marginTop: spacing.sm,
  },
  meta: {
    color: colors.primary,
    fontFamily: 'Poppins_500Medium',
  },
  description: {
    marginTop: spacing.md,
    color: colors.muted,
    fontFamily: 'Poppins_400Regular',
  },
});

export default NotesViewerScreen;
