import React, { useEffect } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { colors, spacing } from '../lib/theme';
import Ionicons from '@expo/vector-icons/Ionicons';
import Animated, { FadeInDown } from 'react-native-reanimated';

type Props = {
  onFinish: () => void;
};

const SplashScreen = ({ onFinish }: Props) => {
  useEffect(() => {
    const timer = setTimeout(onFinish, 1800);
    return () => clearTimeout(timer);
  }, [onFinish]);

  return (
    <View style={styles.container}>
      <Animated.View entering={FadeInDown.duration(700)} style={styles.logoWrap}>
        <Ionicons name="school" size={42} color={colors.card} />
      </Animated.View>
      <Animated.Text entering={FadeInDown.delay(200)} style={styles.title}>
        Raza Ki Kaksha
      </Animated.Text>
      <Animated.Text entering={FadeInDown.delay(400)} style={styles.tagline}>
        Organic Chemistry Made Classroom Simple
      </Animated.Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoWrap: {
    width: 88,
    height: 88,
    borderRadius: 44,
    backgroundColor: colors.accent,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    marginTop: spacing.md,
    fontSize: 28,
    color: colors.card,
    fontFamily: 'Montserrat_700Bold',
  },
  tagline: {
    marginTop: spacing.sm,
    fontSize: 14,
    color: '#E7F5EF',
    fontFamily: 'Poppins_400Regular',
  },
});

export default SplashScreen;
