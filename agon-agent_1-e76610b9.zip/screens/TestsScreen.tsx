import React from 'react';
import { FlatList, StyleSheet, View } from 'react-native';
import { colors, spacing } from '../lib/theme';
import SectionHeader from '../components/SectionHeader';
import ListCard from '../components/ListCard';
import { tests } from '../lib/data';

const TestsScreen = ({ navigation }: { navigation: any }) => {
  return (
    <FlatList
      data={tests}
      keyExtractor={(item) => item.id}
      contentContainerStyle={styles.container}
      ListHeaderComponent={
        <View>
          <SectionHeader title="Test Series" subtitle="Chapter-wise and mock tests" />
        </View>
      }
      renderItem={({ item }) => (
        <ListCard
          title={item.title}
          subtitle={`${item.questions.length} questions`}
          icon="clipboard"
          onPress={() => navigation.navigate('TestRunner', { id: item.id })}
        />
      )}
    />
  );
};

const styles = StyleSheet.create({
  container: {
    padding: spacing.lg,
    backgroundColor: colors.background,
  },
});

export default TestsScreen;
