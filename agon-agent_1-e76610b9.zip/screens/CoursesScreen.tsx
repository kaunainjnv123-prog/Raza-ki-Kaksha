import React, { useMemo, useState } from 'react';
import { FlatList, StyleSheet, Text, TextInput, View } from 'react-native';
import { colors, radius, spacing } from '../lib/theme';
import SectionHeader from '../components/SectionHeader';
import ListCard from '../components/ListCard';
import { chapters, lectures } from '../lib/data';
import Ionicons from '@expo/vector-icons/Ionicons';

type Props = {
  navigation: any;
};

const CoursesScreen = ({ navigation }: Props) => {
  const [query, setQuery] = useState('');

  const filteredChapters = useMemo(
    () =>
      chapters.filter((chapter) => chapter.toLowerCase().includes(query.toLowerCase())),
    [query]
  );

  return (
    <FlatList
      data={filteredChapters}
      keyExtractor={(item) => item}
      contentContainerStyle={styles.container}
      ListHeaderComponent={
        <View>
          <SectionHeader
            title="Class 12 CBSE Organic Chemistry"
            subtitle="Chapter-wise lecture modules"
          />
          <View style={styles.searchRow}>
            <Ionicons name="search" size={18} color={colors.muted} />
            <TextInput
              placeholder="Search chapters or topics"
              placeholderTextColor={colors.muted}
              value={query}
              onChangeText={setQuery}
              style={styles.searchInput}
            />
          </View>
          <View style={styles.heroCard}>
            <Text style={styles.heroTitle}>Total lectures: {lectures.length}</Text>
            <Text style={styles.heroSubtitle}>Includes recorded classes, live sessions, and assignments.</Text>
          </View>
          <Text style={styles.sectionTitle}>Chapters</Text>
        </View>
      }
      renderItem={({ item }) => (
        <ListCard
          title={item}
          subtitle="Video lectures • Notes • Practice"
          pill="Module"
          icon="book"
          onPress={() => navigation.navigate('CourseDetail', { chapter: item })}
        />
      )}
    />
  );
};

const styles = StyleSheet.create({
  container: {
    padding: spacing.lg,
    backgroundColor: colors.background,
  },
  searchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.card,
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    marginBottom: spacing.md,
    height: 48,
  },
  searchInput: {
    flex: 1,
    marginLeft: spacing.sm,
    fontFamily: 'Poppins_400Regular',
    color: colors.text,
  },
  heroCard: {
    backgroundColor: colors.primary,
    borderRadius: radius.lg,
    padding: spacing.lg,
    marginBottom: spacing.lg,
  },
  heroTitle: {
    color: colors.card,
    fontSize: 18,
    fontFamily: 'Montserrat_700Bold',
  },
  heroSubtitle: {
    marginTop: spacing.xs,
    color: '#E7F5EF',
    fontFamily: 'Poppins_400Regular',
  },
  sectionTitle: {
    fontFamily: 'Montserrat_700Bold',
    color: colors.text,
    marginBottom: spacing.sm,
  },
});

export default CoursesScreen;
