import React from 'react';
import { FlatList, StyleSheet, Text, View } from 'react-native';
import { colors, spacing } from '../lib/theme';
import SectionHeader from '../components/SectionHeader';
import ListCard from '../components/ListCard';
import { lectures, materials, tests } from '../lib/data';

const CourseDetailScreen = ({ navigation, route }: { navigation: any; route: any }) => {
  const chapter = route.params?.chapter ?? lectures[0].chapter;
  const chapterLectures = lectures.filter((lecture) => lecture.chapter === chapter);
  const chapterMaterials = materials.filter((item) => item.chapter === chapter);
  const chapterTests = tests.filter((test) => test.chapter === chapter);

  return (
    <FlatList
      data={chapterLectures}
      keyExtractor={(item) => item.id}
      contentContainerStyle={styles.container}
      ListHeaderComponent={
        <View>
          <Text style={styles.title}>{chapter}</Text>
          <Text style={styles.subtitle}>Video lectures, notes, practice problems, and assignments.</Text>
          <SectionHeader title="Lecture Videos" />
        </View>
      }
      renderItem={({ item }) => (
        <ListCard
          title={item.title}
          subtitle={`${item.duration} • ${item.type}`}
          meta={item.date}
          icon="play-circle"
          onPress={() => navigation.navigate('LecturePlayer', { id: item.id })}
        />
      )}
      ListFooterComponent={
        <View>
          <SectionHeader title="Study Notes" />
          {chapterMaterials.map((material) => (
            <ListCard
              key={material.id}
              title={material.title}
              subtitle={material.type}
              meta={material.size}
              icon="document"
              onPress={() => navigation.navigate('NotesViewer', { id: material.id })}
            />
          ))}
          <SectionHeader title="Assignments & Tests" />
          {chapterTests.map((test) => (
            <ListCard
              key={test.id}
              title={test.title}
              subtitle={`${test.questions.length} questions`}
              icon="clipboard"
              onPress={() => navigation.navigate('TestRunner', { id: test.id })}
            />
          ))}
          {chapterTests.length === 0 ? (
            <Text style={styles.empty}>No tests for this chapter yet.</Text>
          ) : null}
        </View>
      }
    />
  );
};

const styles = StyleSheet.create({
  container: {
    padding: spacing.lg,
    backgroundColor: colors.background,
  },
  title: {
    fontSize: 22,
    fontFamily: 'Montserrat_700Bold',
    color: colors.text,
  },
  subtitle: {
    marginTop: spacing.xs,
    color: colors.muted,
    fontFamily: 'Poppins_400Regular',
    marginBottom: spacing.lg,
  },
  empty: {
    color: colors.muted,
    fontFamily: 'Poppins_400Regular',
    marginTop: spacing.sm,
  },
});

export default CourseDetailScreen;
