import React from 'react';
import { FlatList, StyleSheet, Text, View } from 'react-native';
import { colors, radius, spacing } from '../lib/theme';
import SectionHeader from '../components/SectionHeader';
import { tests } from '../lib/data';
import { useApp } from '../lib/AppContext';
import Pill from '../components/Pill';

const ResultsScreen = ({ route }: { route: any }) => {
  const { results } = useApp();
  const current = results.find((item) => item.id === route.params?.id) ?? results[0];

  if (!current) {
    return (
      <View style={styles.empty}>
        <Text style={styles.emptyText}>No results yet. Attempt a test to see analytics.</Text>
      </View>
    );
  }

  const test = tests.find((item) => item.id === current.testId);
  const percent = Math.round((current.score / current.total) * 100);

  return (
    <FlatList
      data={test?.questions ?? []}
      keyExtractor={(item) => item.id}
      contentContainerStyle={styles.container}
      ListHeaderComponent={
        <View>
          <View style={styles.scoreCard}>
            <Text style={styles.score}>{current.score}/{current.total}</Text>
            <Text style={styles.percent}>{percent}%</Text>
            <Text style={styles.title}>Test Analysis</Text>
            <Text style={styles.subtitle}>{test?.title}</Text>
          </View>
          <SectionHeader title="Question Review" subtitle="Detailed explanation" />
        </View>
      }
      renderItem={({ item, index }) => {
        const selected = current.breakdown[index];
        const isCorrect = selected === item.answer;
        return (
          <View style={styles.reviewCard}>
            <View style={styles.reviewHeader}>
              <Text style={styles.question}>{index + 1}. {item.question}</Text>
              <Pill label={isCorrect ? 'Correct' : 'Incorrect'} tone={isCorrect ? 'primary' : 'accent'} />
            </View>
            <Text style={styles.answer}>Your answer: {selected >= 0 ? item.options[selected] : 'Skipped'}</Text>
            <Text style={styles.answer}>Correct answer: {item.options[item.answer]}</Text>
            <Text style={styles.explanation}>{item.explanation}</Text>
          </View>
        );
      }}
    />
  );
};

const styles = StyleSheet.create({
  container: {
    padding: spacing.lg,
    backgroundColor: colors.background,
  },
  scoreCard: {
    backgroundColor: colors.primary,
    borderRadius: radius.lg,
    padding: spacing.lg,
    marginBottom: spacing.lg,
  },
  score: {
    fontSize: 32,
    color: colors.card,
    fontFamily: 'Montserrat_700Bold',
  },
  percent: {
    marginTop: spacing.xs,
    color: '#E7F5EF',
    fontFamily: 'Poppins_500Medium',
  },
  title: {
    marginTop: spacing.md,
    color: colors.card,
    fontFamily: 'Montserrat_700Bold',
    fontSize: 18,
  },
  subtitle: {
    marginTop: 4,
    color: '#E7F5EF',
    fontFamily: 'Poppins_400Regular',
  },
  reviewCard: {
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    padding: spacing.md,
    marginBottom: spacing.md,
  },
  reviewHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  question: {
    flex: 1,
    fontFamily: 'Poppins_600SemiBold',
    color: colors.text,
    marginRight: spacing.sm,
  },
  answer: {
    color: colors.muted,
    fontFamily: 'Poppins_400Regular',
    marginBottom: spacing.xs,
  },
  explanation: {
    marginTop: spacing.xs,
    color: colors.text,
    fontFamily: 'Poppins_400Regular',
  },
  empty: {
    flex: 1,
    backgroundColor: colors.background,
    alignItems: 'center',
    justifyContent: 'center',
    padding: spacing.lg,
  },
  emptyText: {
    color: colors.muted,
    fontFamily: 'Poppins_400Regular',
    textAlign: 'center',
  },
});

export default ResultsScreen;
