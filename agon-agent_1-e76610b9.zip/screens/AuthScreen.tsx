import React, { useState } from 'react';
import {
  KeyboardAvoidingView,
  Platform,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { colors, radius, spacing } from '../lib/theme';
import PrimaryButton from '../components/PrimaryButton';
import { useApp } from '../lib/AppContext';
import Ionicons from '@expo/vector-icons/Ionicons';

const AuthScreen = ({ onDone }: { onDone: () => void }) => {
  const { role, setRole, setName } = useApp();
  const [name, updateName] = useState('');
  const [identifier, setIdentifier] = useState('');

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <View style={styles.header}>
        <Text style={styles.title}>Welcome to Raza Ki Kaksha</Text>
        <Text style={styles.subtitle}>Sign in to continue learning organic chemistry.</Text>
      </View>
      <View style={styles.card}>
        <View style={styles.roleRow}>
          <TouchableOpacity
            onPress={() => setRole('student')}
            style={[styles.roleChip, role === 'student' && styles.roleChipActive]}
          >
            <Ionicons name="person" size={18} color={role === 'student' ? '#fff' : colors.primary} />
            <Text style={[styles.roleText, role === 'student' && styles.roleTextActive]}>Student</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => setRole('admin')}
            style={[styles.roleChip, role === 'admin' && styles.roleChipActive]}
          >
            <Ionicons name="briefcase" size={18} color={role === 'admin' ? '#fff' : colors.primary} />
            <Text style={[styles.roleText, role === 'admin' && styles.roleTextActive]}>Admin</Text>
          </TouchableOpacity>
        </View>
        <Text style={styles.label}>Full Name</Text>
        <TextInput
          placeholder="Enter your name"
          placeholderTextColor="#A0A5A9"
          style={styles.input}
          value={name}
          onChangeText={updateName}
          returnKeyType="next"
        />
        <Text style={styles.label}>Email or Phone</Text>
        <TextInput
          placeholder="name@email.com"
          placeholderTextColor="#A0A5A9"
          style={styles.input}
          keyboardType="email-address"
          value={identifier}
          onChangeText={setIdentifier}
        />
        <PrimaryButton
          title={role === 'admin' ? 'Enter Admin Console' : 'Start Learning'}
          onPress={() => {
            setName(name || 'Raza Learner');
            onDone();
          }}
          style={{ marginTop: spacing.md }}
        />
        <Text style={styles.helper}>By continuing you agree to secure login and data encryption.</Text>
      </View>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    padding: spacing.lg,
    justifyContent: 'center',
  },
  header: {
    marginBottom: spacing.lg,
  },
  title: {
    fontSize: 24,
    fontFamily: 'Montserrat_700Bold',
    color: colors.text,
  },
  subtitle: {
    marginTop: spacing.sm,
    color: colors.muted,
    fontFamily: 'Poppins_400Regular',
  },
  card: {
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    padding: spacing.lg,
  },
  roleRow: {
    flexDirection: 'row',
    gap: spacing.sm,
    marginBottom: spacing.md,
  },
  roleChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    borderWidth: 1,
    borderColor: colors.primary,
    borderRadius: radius.md,
    paddingVertical: spacing.xs,
    paddingHorizontal: spacing.md,
  },
  roleChipActive: {
    backgroundColor: colors.primary,
  },
  roleText: {
    fontFamily: 'Poppins_500Medium',
    color: colors.primary,
  },
  roleTextActive: {
    color: '#fff',
  },
  label: {
    fontFamily: 'Poppins_500Medium',
    marginBottom: spacing.xs,
    color: colors.text,
  },
  input: {
    backgroundColor: '#F6F9F8',
    borderRadius: radius.md,
    padding: spacing.sm,
    marginBottom: spacing.md,
    fontFamily: 'Poppins_400Regular',
  },
  helper: {
    marginTop: spacing.sm,
    fontSize: 12,
    color: colors.muted,
    fontFamily: 'Poppins_400Regular',
    textAlign: 'center',
  },
});

export default AuthScreen;
