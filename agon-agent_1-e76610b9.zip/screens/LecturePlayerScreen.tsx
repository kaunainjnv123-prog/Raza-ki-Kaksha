import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { colors, radius, spacing } from '../lib/theme';
import { lectures } from '../lib/data';
import PrimaryButton from '../components/PrimaryButton';
import { useApp } from '../lib/AppContext';
import Ionicons from '@expo/vector-icons/Ionicons';

const LecturePlayerScreen = ({ route }: { route: any }) => {
  const { id } = route.params;
  const lecture = lectures.find((item) => item.id === id) ?? lectures[0];
  const { bookmarks, toggleBookmark, markLectureComplete } = useApp();
  const isBookmarked = bookmarks.includes(lecture.id);

  return (
    <View style={styles.container}>
      <View style={styles.player}>
        <Ionicons name="play" size={40} color={colors.card} />
        <Text style={styles.playerText}>Lecture Playback</Text>
        <Text style={styles.playerSubtext}>Streaming with adaptive quality</Text>
      </View>
      <Text style={styles.title}>{lecture.title}</Text>
      <Text style={styles.subtitle}>{lecture.chapter}</Text>
      <View style={styles.metaRow}>
        <Text style={styles.meta}>{lecture.duration}</Text>
        <Text style={styles.meta}>{lecture.type}</Text>
      </View>
      <Text style={styles.description}>
        In this session, we break down key organic chemistry reactions with step-by-step classroom
        explanations, mechanisms, and tricks for board exams.
      </Text>
      <View style={styles.buttonRow}>
        <PrimaryButton
          title={isBookmarked ? 'Bookmarked' : 'Bookmark'}
          variant={isBookmarked ? 'outline' : 'primary'}
          icon={<Ionicons name="bookmark" size={18} color={isBookmarked ? colors.primary : '#fff'} />}
          onPress={() => toggleBookmark(lecture.id)}
          style={{ flex: 1 }}
        />
        <PrimaryButton
          title="Mark Complete"
          variant="outline"
          icon={<Ionicons name="checkmark" size={18} color={colors.primary} />}
          onPress={() => markLectureComplete(lecture.id)}
          style={{ flex: 1 }}
        />
      </View>
      <View style={styles.downloadCard}>
        <Ionicons name="cloud-download" size={20} color={colors.accent} />
        <Text style={styles.downloadText}>Download for offline access</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    padding: spacing.lg,
  },
  player: {
    height: 200,
    borderRadius: radius.lg,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  playerText: {
    marginTop: spacing.sm,
    color: colors.card,
    fontFamily: 'Montserrat_700Bold',
  },
  playerSubtext: {
    color: '#E7F5EF',
    fontFamily: 'Poppins_400Regular',
  },
  title: {
    marginTop: spacing.lg,
    fontSize: 22,
    color: colors.text,
    fontFamily: 'Montserrat_700Bold',
  },
  subtitle: {
    marginTop: spacing.xs,
    color: colors.muted,
    fontFamily: 'Poppins_400Regular',
  },
  metaRow: {
    flexDirection: 'row',
    gap: spacing.md,
    marginTop: spacing.sm,
  },
  meta: {
    color: colors.primary,
    fontFamily: 'Poppins_500Medium',
  },
  description: {
    marginTop: spacing.md,
    color: colors.muted,
    fontFamily: 'Poppins_400Regular',
  },
  buttonRow: {
    flexDirection: 'row',
    gap: spacing.sm,
    marginTop: spacing.lg,
  },
  downloadCard: {
    marginTop: spacing.lg,
    backgroundColor: colors.card,
    borderRadius: radius.md,
    padding: spacing.md,
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  downloadText: {
    fontFamily: 'Poppins_500Medium',
    color: colors.text,
  },
});

export default LecturePlayerScreen;
