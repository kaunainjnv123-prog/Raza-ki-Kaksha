import React from 'react';
import { FlatList, StyleSheet, View } from 'react-native';
import { colors, spacing } from '../lib/theme';
import SectionHeader from '../components/SectionHeader';
import ListCard from '../components/ListCard';
import { useApp } from '../lib/AppContext';

const NotificationsScreen = () => {
  const { notifications } = useApp();

  return (
    <FlatList
      data={notifications}
      keyExtractor={(item) => item.id}
      contentContainerStyle={styles.container}
      ListHeaderComponent={<SectionHeader title="Notifications" subtitle="Class reminders and alerts" />}
      renderItem={({ item }) => (
        <ListCard
          title={item.title}
          subtitle={item.body}
          meta={`${item.type} • ${item.date}`}
          icon={item.read ? 'checkmark-circle' : 'notifications'}
        />
      )}
    />
  );
};

const styles = StyleSheet.create({
  container: {
    padding: spacing.lg,
    backgroundColor: colors.background,
  },
});

export default NotificationsScreen;
