import React, { useState } from 'react';
import { FlatList, StyleSheet, Text, TextInput, View } from 'react-native';
import { colors, radius, spacing } from '../lib/theme';
import SectionHeader from '../components/SectionHeader';
import ListCard from '../components/ListCard';
import PrimaryButton from '../components/PrimaryButton';
import { useApp } from '../lib/AppContext';
import Ionicons from '@expo/vector-icons/Ionicons';

const DoubtsScreen = ({ navigation }: { navigation: any }) => {
  const { doubts, addDoubt } = useApp();
  const [question, setQuestion] = useState('');

  return (
    <FlatList
      data={doubts}
      keyExtractor={(item) => item.id}
      contentContainerStyle={styles.container}
      ListHeaderComponent={
        <View>
          <SectionHeader title="Doubt Solving" subtitle="Ask questions and receive replies" />
          <View style={styles.askCard}>
            <Text style={styles.askTitle}>Ask your doubt</Text>
            <TextInput
              placeholder="Type your chemistry question"
              placeholderTextColor={colors.muted}
              value={question}
              onChangeText={setQuestion}
              style={styles.input}
              multiline
            />
            <PrimaryButton
              title="Upload Question"
              icon={<Ionicons name="cloud-upload" size={18} color="#fff" />}
              onPress={() => {
                if (question.trim()) {
                  addDoubt(question.trim());
                  setQuestion('');
                }
              }}
            />
          </View>
          <Text style={styles.listTitle}>Discussion Threads</Text>
        </View>
      }
      renderItem={({ item }) => (
        <ListCard
          title={item.question}
          subtitle={`${item.student} • ${item.status}`}
          icon="help-circle"
          onPress={() => navigation.navigate('DoubtDetail', { id: item.id })}
        />
      )}
    />
  );
};

const styles = StyleSheet.create({
  container: {
    padding: spacing.lg,
    backgroundColor: colors.background,
  },
  askCard: {
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    padding: spacing.md,
    marginBottom: spacing.lg,
  },
  askTitle: {
    fontFamily: 'Montserrat_700Bold',
    color: colors.text,
    marginBottom: spacing.sm,
  },
  input: {
    backgroundColor: '#F6F9F8',
    borderRadius: radius.md,
    padding: spacing.sm,
    minHeight: 80,
    marginBottom: spacing.md,
    fontFamily: 'Poppins_400Regular',
  },
  listTitle: {
    fontFamily: 'Montserrat_700Bold',
    color: colors.text,
    marginBottom: spacing.sm,
  },
});

export default DoubtsScreen;
