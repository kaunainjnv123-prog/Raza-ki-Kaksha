import React, { useMemo, useState } from 'react';
import { FlatList, StyleSheet, TextInput, View } from 'react-native';
import { colors, radius, spacing } from '../lib/theme';
import SectionHeader from '../components/SectionHeader';
import ListCard from '../components/ListCard';
import Ionicons from '@expo/vector-icons/Ionicons';
import { materials } from '../lib/data';
import { useApp } from '../lib/AppContext';

const MaterialsScreen = ({ navigation }: { navigation: any }) => {
  const { downloads, toggleDownload } = useApp();
  const [query, setQuery] = useState('');

  const filtered = useMemo(
    () => materials.filter((item) => item.title.toLowerCase().includes(query.toLowerCase())),
    [query]
  );

  return (
    <FlatList
      data={filtered}
      keyExtractor={(item) => item.id}
      contentContainerStyle={styles.container}
      ListHeaderComponent={
        <View>
          <SectionHeader title="Study Materials" subtitle="Notes, mind maps, and revision sheets" />
          <View style={styles.searchRow}>
            <Ionicons name="search" size={18} color={colors.muted} />
            <TextInput
              placeholder="Search notes, formulas"
              placeholderTextColor={colors.muted}
              value={query}
              onChangeText={setQuery}
              style={styles.searchInput}
            />
          </View>
        </View>
      }
      renderItem={({ item }) => {
        const isDownloaded = downloads.includes(item.id);
        return (
          <ListCard
            title={item.title}
            subtitle={`${item.chapter} • ${item.type}`}
            meta={item.size}
            icon="document-text"
            onPress={() => navigation.navigate('NotesViewer', { id: item.id })}
            rightSlot={
              <Ionicons
                name={isDownloaded ? 'checkmark-circle' : 'cloud-download'}
                size={20}
                color={isDownloaded ? colors.success : colors.muted}
                onPress={() => toggleDownload(item.id)}
              />
            }
          />
        );
      }}
    />
  );
};

const styles = StyleSheet.create({
  container: {
    padding: spacing.lg,
    backgroundColor: colors.background,
  },
  searchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.card,
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    height: 48,
    marginBottom: spacing.md,
  },
  searchInput: {
    flex: 1,
    marginLeft: spacing.sm,
    fontFamily: 'Poppins_400Regular',
    color: colors.text,
  },
});

export default MaterialsScreen;
