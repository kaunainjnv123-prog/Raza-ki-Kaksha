import React, { useState } from 'react';
import { FlatList, StyleSheet, Text, TextInput, View } from 'react-native';
import { colors, radius, spacing } from '../lib/theme';
import SectionHeader from '../components/SectionHeader';
import PrimaryButton from '../components/PrimaryButton';
import ListCard from '../components/ListCard';
import { useApp } from '../lib/AppContext';
import Ionicons from '@expo/vector-icons/Ionicons';

const AdminPanelScreen = () => {
  const { uploads, addUpload, addAnnouncement, addNotification } = useApp();
  const [title, setTitle] = useState('');
  const [type, setType] = useState('Lecture Video');
  const [announcement, setAnnouncement] = useState('');

  return (
    <FlatList
      data={uploads}
      keyExtractor={(item) => item.id}
      contentContainerStyle={styles.container}
      ListHeaderComponent={
        <View>
          <SectionHeader title="Admin Upload Panel" subtitle="Manage classroom content" />
          <View style={styles.formCard}>
            <Text style={styles.label}>Upload Type</Text>
            <View style={styles.typeRow}>
              {['Lecture Video', 'PDF Notes', 'Assignment', 'Quiz'].map((item) => (
                <Text
                  key={item}
                  onPress={() => setType(item)}
                  style={[styles.typeChip, type === item && styles.typeChipActive]}
                >
                  {item}
                </Text>
              ))}
            </View>
            <Text style={styles.label}>Title</Text>
            <TextInput
              placeholder="Enter content title"
              placeholderTextColor={colors.muted}
              style={styles.input}
              value={title}
              onChangeText={setTitle}
            />
            <PrimaryButton
              title="Upload to Course"
              icon={<Ionicons name="cloud-upload" size={18} color="#fff" />}
              onPress={() => {
                if (title.trim()) {
                  addUpload(type, title.trim());
                  setTitle('');
                }
              }}
            />
          </View>
          <View style={styles.formCard}>
            <Text style={styles.label}>Announcement</Text>
            <TextInput
              placeholder="Share announcement with students"
              placeholderTextColor={colors.muted}
              style={styles.input}
              value={announcement}
              onChangeText={setAnnouncement}
            />
            <PrimaryButton
              title="Send Announcement"
              icon={<Ionicons name="megaphone" size={18} color="#fff" />}
              onPress={() => {
                if (announcement.trim()) {
                  addAnnouncement('Teacher Update', announcement.trim());
                  addNotification('Announcement', announcement.trim(), 'Announcement');
                  setAnnouncement('');
                }
              }}
            />
          </View>
          <SectionHeader title="Recent Uploads" subtitle="Edit or manage content" />
        </View>
      }
      renderItem={({ item }) => (
        <ListCard
          title={item.title}
          subtitle={item.type}
          meta={item.date}
          icon="folder"
        />
      )}
    />
  );
};

const styles = StyleSheet.create({
  container: {
    padding: spacing.lg,
    backgroundColor: colors.background,
  },
  formCard: {
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    padding: spacing.md,
    marginBottom: spacing.lg,
  },
  label: {
    fontFamily: 'Poppins_600SemiBold',
    color: colors.text,
    marginBottom: spacing.xs,
  },
  input: {
    backgroundColor: '#F6F9F8',
    borderRadius: radius.md,
    padding: spacing.sm,
    marginBottom: spacing.md,
    fontFamily: 'Poppins_400Regular',
  },
  typeRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
    marginBottom: spacing.md,
  },
  typeChip: {
    borderWidth: 1,
    borderColor: colors.primary,
    paddingVertical: 6,
    paddingHorizontal: spacing.sm,
    borderRadius: radius.md,
    color: colors.primary,
    fontFamily: 'Poppins_500Medium',
  },
  typeChipActive: {
    backgroundColor: colors.primary,
    color: colors.card,
  },
});

export default AdminPanelScreen;
