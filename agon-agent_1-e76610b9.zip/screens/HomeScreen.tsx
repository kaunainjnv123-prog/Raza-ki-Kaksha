import React from 'react';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { colors, radius, spacing } from '../lib/theme';
import SectionHeader from '../components/SectionHeader';
import ListCard from '../components/ListCard';
import StatCard from '../components/StatCard';
import ProgressBar from '../components/ProgressBar';
import { announcements, lectures, upcomingClasses, performanceStats } from '../lib/data';
import { useApp } from '../lib/AppContext';
import Ionicons from '@expo/vector-icons/Ionicons';
import Animated, { FadeInDown } from 'react-native-reanimated';
import EmptyState from '../components/EmptyState';

type Props = {
  navigation: any;
};

const HomeScreen = ({ navigation }: Props) => {
  const { name, results } = useApp();
  const latestResult = results[0];

  return (
    <FlatList
      data={announcements}
      keyExtractor={(item) => item.id}
      contentContainerStyle={styles.container}
      ListHeaderComponent={
        <View>
          <Animated.View entering={FadeInDown.duration(500)} style={styles.hero}>
            <View style={styles.heroHeader}>
              <View>
                <Text style={styles.welcome}>Welcome back,</Text>
                <Text style={styles.name}>{name}</Text>
              </View>
              <Pressable onPress={() => navigation.navigate('Notifications')} style={styles.bell}>
                <Ionicons name="notifications" size={20} color={colors.primary} />
              </Pressable>
            </View>
            <Text style={styles.tagline}>Keep the momentum going in Organic Chemistry.</Text>
            <View style={styles.statRow}>
              <StatCard title="Score" value={latestResult ? `${latestResult.score}/${latestResult.total}` : '78%'} subtitle="Latest test" />
              <StatCard title="Streak" value="5 Days" subtitle="Consistency" />
            </View>
          </Animated.View>

          <SectionHeader title="Performance Snapshot" subtitle="Track your learning progress" />
          <View style={styles.progressCard}>
            {performanceStats.map((stat) => (
              <ProgressBar key={stat.label} label={stat.label} value={stat.value} total={stat.total} />
            ))}
          </View>

          <SectionHeader title="Latest Announcements" subtitle="From your teacher" />
        </View>
      }
      renderItem={({ item }) => (
        <ListCard
          title={item.title}
          subtitle={item.body}
          meta={item.date}
          icon="megaphone"
          onPress={() => navigation.navigate('Notifications')}
        />
      )}
      ListFooterComponent={
        <View>
          <SectionHeader title="Upcoming Classes" subtitle="Join live sessions" />
          {upcomingClasses.map((cls) => (
            <ListCard
              key={cls.id}
              title={cls.topic}
              subtitle={cls.time}
              icon="calendar"
              pill="Live"
              onPress={() => navigation.navigate('CourseDetail')}
            />
          ))}
          <SectionHeader title="Recently Uploaded" subtitle="Fresh lectures for you" />
          {lectures.slice(0, 2).map((lecture) => (
            <ListCard
              key={lecture.id}
              title={lecture.title}
              subtitle={lecture.chapter}
              meta={lecture.duration}
              pill={lecture.type}
              icon="play-circle"
              onPress={() => navigation.navigate('LecturePlayer', { id: lecture.id })}
            />
          ))}
          <View style={styles.quickRow}>
            <Pressable style={styles.quickCard} onPress={() => navigation.navigate('Tests')}>
              <Ionicons name="clipboard" size={24} color={colors.accent} />
              <Text style={styles.quickText}>Quick Test</Text>
            </Pressable>
            <Pressable style={styles.quickCard} onPress={() => navigation.navigate('Materials')}>
              <Ionicons name="folder" size={24} color={colors.accent} />
              <Text style={styles.quickText}>Notes Vault</Text>
            </Pressable>
          </View>
          {lectures.length === 0 ? (
            <EmptyState
              title="No lectures yet"
              subtitle="New lectures will appear here once the teacher uploads them."
            />
          ) : null}
        </View>
      }
    />
  );
};

const styles = StyleSheet.create({
  container: {
    padding: spacing.lg,
    backgroundColor: colors.background,
  },
  hero: {
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    padding: spacing.lg,
    marginBottom: spacing.lg,
  },
  heroHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  bell: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#E6F4F0',
    alignItems: 'center',
    justifyContent: 'center',
  },
  welcome: {
    color: colors.muted,
    fontFamily: 'Poppins_400Regular',
  },
  name: {
    fontSize: 22,
    color: colors.text,
    fontFamily: 'Montserrat_700Bold',
  },
  tagline: {
    marginTop: spacing.sm,
    color: colors.muted,
    fontFamily: 'Poppins_400Regular',
  },
  statRow: {
    flexDirection: 'row',
    gap: spacing.sm,
    marginTop: spacing.md,
  },
  progressCard: {
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    padding: spacing.md,
    marginBottom: spacing.lg,
  },
  quickRow: {
    flexDirection: 'row',
    gap: spacing.sm,
    marginTop: spacing.md,
  },
  quickCard: {
    flex: 1,
    backgroundColor: colors.card,
    borderRadius: radius.md,
    padding: spacing.md,
    alignItems: 'center',
  },
  quickText: {
    marginTop: spacing.xs,
    fontFamily: 'Poppins_500Medium',
    color: colors.text,
  },
});

export default HomeScreen;
